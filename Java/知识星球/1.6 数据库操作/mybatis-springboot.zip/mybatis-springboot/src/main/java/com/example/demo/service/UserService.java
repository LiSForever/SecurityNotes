package com.example.demo.service;

import com.example.demo.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 编号7089
 */
@Service
public interface UserService {
    // 添加数据
    public boolean addUser(User user);
    // 删除数据
    public boolean delUserByName(String userName);
    // 修改数据
    public boolean updateUserByUserId(User user);
    // 根据id查询数据
    public User getUser(int id);
    // 查询全部数据
    public List<User> getUsers();
}
