package com.example.demo.service.impl;

import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 编号7089
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    /**
     * 添加用户
     * */
    @Override
    public boolean addUser(User user) {
        boolean flag;// 默认值是false
        flag = userMapper.addUser(user);
        return flag;
    }

    /**
     * 根据id删除用户
     * */
    @Override
    public boolean delUserByName(String userName) {
        boolean flag;// 默认值是false
        flag = userMapper.delUser(userName);
        return flag;
    }

    /**
     * 修改用戶
     * */
    @Override
    public boolean updateUserByUserId(User user) {
        boolean flag;// 默认值是fals
        flag = userMapper.updateUser(user);
        return flag;
    }

    /**
     * 根据id获取用户
     * */
    @Override
    public User getUser(int id) {
        User user = userMapper.getUser(id);
        return user;
    }

    /**
     * 查询全部数据
     * */
    @Override
    public List<User> getUsers() {
        List<User> users = userMapper.getUsers();
        return users;
    }
}