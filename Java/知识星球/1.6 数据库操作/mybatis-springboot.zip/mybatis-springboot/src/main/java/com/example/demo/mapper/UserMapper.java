package com.example.demo.mapper;

import com.example.demo.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 编号7089
 */
@Mapper
public interface UserMapper {

    /**
     * 新增用户
     * @param user
     * @return
     */
    public boolean addUser(User user);

    /**
     * 删除用户
     * @param userName
     * @return
     */
    public boolean delUser(String userName);

    /**
     * 修改用户
     *@param user
     *@return
     * */
    public boolean updateUser(User user);

    /**
     * 单个查询
     * @param id
     * @return
     */
    public User getUser(int id);

    /**
     * 查询全部
     * @return
     */
    public List<User> getUsers();
}
