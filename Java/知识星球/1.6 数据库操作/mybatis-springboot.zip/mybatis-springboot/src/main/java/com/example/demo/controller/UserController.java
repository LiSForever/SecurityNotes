package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 编号7089
 */
@Controller
@RestController
public class UserController {

    @Autowired
    private UserService service;

    /**
     * 新增用户
     * @param user
     * @return
     */
    @RequestMapping(value="/add", method=RequestMethod.POST)
    @ResponseBody
    public String addUser(User user){
        boolean flag = service.addUser(user);
        if (flag) {
            return "success";
        } else {
            return "faile";
        }
    }

    /**
     * 删除用户
     *
     * @param name
     * @return
     * */
    @RequestMapping(value="/del", method=RequestMethod.POST)
    @ResponseBody
    public String delUserByName(@RequestParam("name") String userName) {

        boolean flag = service.delUserByName(userName);
        if (flag) {
            return "success";
        } else {
            return "faile";
        }
    }

    /**
     * 修改用户
     *
     * @param User
     * @return
     * */
    @RequestMapping(value="/updata", method=RequestMethod.POST)
    @ResponseBody
    public String updateUserByName(User user) {
        boolean flag = service.updateUserByUserId(user);
        if (flag) {
            return "success";
        } else {
            return "faile";
        }
    }

    /**
     * 单个查询
     * @param id
     * @return
     */
    @RequestMapping(value="/get/{id}", method= RequestMethod.GET)
    public User getUser(@PathVariable("id") int id){
        User user = service.getUser(id);
        return user;
    }

    /**
     * 查询全部
     * @return
     */
    @RequestMapping(value="/getUser/list", method=RequestMethod.GET)
    @ResponseBody // @ResponseBody - 返回json字符串
    public List<User> getUsers(){
        List<User> users = service.getUsers();
        return users;
    }


}
