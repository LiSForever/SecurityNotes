import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/**
 * 编号7089
 */
public class ExecProcessBuilder {
    public static void main(String[] args) throws IOException {
        ProcessBuilder processBuilder = new ProcessBuilder();
        // 在Windows上运行这个命令，cmd， /c 参数是在运行后终止
        processBuilder.command("cmd.exe", "/c", "ping www.baidu.com");
        // 在Linux上运行
        //processBuilder.command("bash", "-c", "ping  baidu.com");
        Process process = processBuilder.start();
        BufferedReader bufferedReader =
                new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            System.out.println(line);
        }
        }
    }

