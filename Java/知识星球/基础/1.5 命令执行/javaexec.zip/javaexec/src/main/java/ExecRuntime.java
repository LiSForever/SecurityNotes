import java.io.*;
import java.nio.charset.Charset;

public class ExecRuntime {
    public static void main(String[] args) throws Exception {
        String command1 = "cmd /c whoami";
        //windows环境下执行
        String[] command2 = {"cmd","/c","ping www.baidu.com"};
        //String[] command2 = {"cmd","/c", "py","-3", "C:\\Users\\powerful\\Desktop\\dirsearch-0.4.2\\dirsearch.py", "-u", "https://www.baidu.com", "-e *"};
        //Linux环境下执行，也可以是bash，
        //String[] command3 = {"/bin/sh", "/root/xxx.sh", "xxx.sh所需的参数"};
        //exec执行字符串命令
        cmdstring(command1);
        //exec以数组方式接受多个参数并执行
        cmdarray(command2);
    }
    //exec执行字符串命令
    private static void cmdstring(String command) throws IOException {
        String line = null;
        Process process = Runtime.getRuntime().exec(command);
        //使用BufferedReader设置编码解决执行命令响应中文乱码问题
        BufferedReader bufferedReader =
                    new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));
        while ((line = bufferedReader.readLine()) != null) {
            System.out.println(line);
        }
    }
    //exec以数组方式接受多个参数并执行
    private static void cmdarray(String[] command) throws IOException {
        String line = null;
        Process process = Runtime.getRuntime().exec(command);
        //使用BufferedReader设置编码解决执行命令响应中文乱码问题
        BufferedReader bufferedReader =
                new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));
        while ((line = bufferedReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}
