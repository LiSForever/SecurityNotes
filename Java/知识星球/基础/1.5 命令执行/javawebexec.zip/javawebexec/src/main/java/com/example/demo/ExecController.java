package com.example.demo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.Charset;

@Controller
@ResponseBody
public class ExecController {

    @RequestMapping("/execRuntimeString")
    public void execRuntimeString(String command, HttpServletResponse response) throws IOException {
        String line = null;
        Process process = Runtime.getRuntime().exec(command);
        BufferedReader bufferedReader =
                new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));
        PrintWriter out = response.getWriter();
        while ((line = bufferedReader.readLine()) != null) {
            //逐行读取
            System.out.println(line);
            out.print(line);
        }
        bufferedReader.close();
    }
    @RequestMapping("/execRuntimeArray")
    public void execRuntimeArray(String command, HttpServletResponse response) throws IOException {
        String line = null;
        String[] commandarray ={"cmd","/c",command};
        Process process = Runtime.getRuntime().exec(commandarray);
        BufferedReader bufferedReader =
                new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));
        PrintWriter out = response.getWriter();
        while ((line = bufferedReader.readLine()) != null) {
            //逐行读取
            System.out.println(line);
            out.print(line);
        }
        bufferedReader.close();
    }

}
