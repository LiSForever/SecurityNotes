package com.example.demo;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

/**
 * 编号7089
 */
@Controller
@ResponseBody
public class ReadFilesController {


    @RequestMapping("/readUsingFiles")
    public String readUsingFiles(String fileName, HttpServletResponse response) throws IOException {
        //使用Java 7中的Files类处理小文件，获取完整的文件数据
        Path path = Paths.get(fileName);
        //将文件读取到字节数组
        byte[] bytes = Files.readAllBytes(path);
        System.out.println("使用File类读取文件.........");
        @SuppressWarnings("unused")
        List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        //将注释去掉，重新运行启动项目，在浏览器键入要读取的文件地址，观察下效果有什么不一样。
        response.reset();
        response.setContentType("application/octet-stream");
        response.addHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));

        System.out.println(new String(bytes));
        return new String(bytes);

    }

    @RequestMapping("/readUsingFileReader")
    public void readUsingFileReader(String fileName, HttpServletResponse response) throws IOException {
        //使用FileReader读取，没有编码支持，效率不高
        File file = new File(fileName);
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String line;
        System.out.println("使用FileReader读取文本文件......");
        //将注释去掉，重新运行启动项目，在浏览器键入要读取的文件地址，观察下效果有什么不一样。
        //response.reset();
        //response.setContentType("application/octet-stream");
        //response.addHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));
        PrintWriter out = response.getWriter();
        while ((line = br.readLine()) != null) {
            //逐行读取
            System.out.println(line);
            out.print(line);
        }
        br.close();
        fr.close();
    }

    @RequestMapping("/ReadBufferedReader")
    public void readBufferedReader(String fileName, HttpServletResponse response) throws IOException{
        File file = new File(fileName);
        FileInputStream fis = new FileInputStream(file);
        InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
        BufferedReader br = new BufferedReader(isr);
        String line;
        //将注释去掉，重新运行启动项目，在浏览器键入要读取的文件地址，观察下效果有什么不一样。
        //response.reset();
        //response.setContentType("application/octet-stream");
        //response.addHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));
        PrintWriter out = response.getWriter();
        System.out.println("使用BufferedReader读取文本文件......");
        while((line = br.readLine()) != null){
            //逐行读取
            System.out.println(line);
            out.print(line);
        }
        br.close();
    }

    @RequestMapping("/readScanner")
    public void readScanner(String fileName, HttpServletResponse response) throws IOException{
        Path path = Paths.get(fileName);
        Scanner scanner = new Scanner(path);
        System.out.println("使用Scanner读取文本文件.....");
        //将注释去掉，重新运行启动项目，在浏览器键入要读取的文件地址，观察下效果有什么不一样。
        //response.reset();
        //response.setContentType("application/octet-stream");
        //response.addHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));
        PrintWriter out = response.getWriter();
        //逐行读取
        while(scanner.hasNextLine()){
            //逐行处理
            String line = scanner.nextLine();
            System.out.println(line);
            out.print(line);
        }
        scanner.close();
    }


    @RequestMapping("/readUsingRandomAccessFile")
    public void readUsingRandomAccessFile(String fileName, HttpServletResponse response) throws IOException{
        RandomAccessFile file = new RandomAccessFile(fileName, "r");
        String str;
        //将注释去掉，重新运行启动项目，在浏览器键入要读取的文件地址，观察下效果有什么不一样。
        //response.reset();
        //response.setContentType("application/octet-stream");
        //response.addHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));
        PrintWriter out = response.getWriter();
        while ((str = file.readLine()) != null) {
            System.out.println("使用RandomAccessFile来实现断点续传读取/下载文件......");
            System.out.println(str);
            out.print(str);
        }
        file.close();
    }

    @RequestMapping("/readUsingCommonsIo")
    public String readUsingCommonsIo(String fileName,HttpServletResponse response) throws IOException{
        File file = new File(fileName);
        //将注释去掉，重新运行启动项目，在浏览器键入要读取的文件地址，观察下效果有什么不一样。
        response.reset();
        response.setContentType("application/octet-stream");
        response.addHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));
        System.out.println("使用Commons-io读取文件......");
        System.out.println(FileUtils.readFileToString(file, StandardCharsets.UTF_8));
        return FileUtils.readFileToString(file, StandardCharsets.UTF_8);
    }

}


