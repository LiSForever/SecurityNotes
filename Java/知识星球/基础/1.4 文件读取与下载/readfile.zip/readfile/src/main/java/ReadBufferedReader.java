import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * 编号7089
 */
public class ReadBufferedReader {
    public static void main(String[] args) throws IOException {
        String fileName = "C:\\Users\\powerful\\Desktop\\test.txt";
        //使用BufferedReader读取，逐行读取,并设置编码为UTF_8
        readUsingBufferedReader(fileName, StandardCharsets.UTF_8);
    }
    private static void readUsingBufferedReader(String fileName, Charset cs) throws IOException {
        File file = new File(fileName);
        FileInputStream fis = new FileInputStream(file);
        InputStreamReader isr = new InputStreamReader(fis, cs);
        BufferedReader br = new BufferedReader(isr);
        String line;
        System.out.println("使用BufferedReader读取文本文件......");
        while((line = br.readLine()) != null){
            //逐行读取
            System.out.println(line);
        }
        br.close();
    }

}
