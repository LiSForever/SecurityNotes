import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 编号7089
 */
public class ReadCommonsIo {
    public static void main(String[] args) throws IOException {
        String fileName = "C:\\Users\\powerful\\Desktop\\test.txt";
        readUsingCommonsIo(fileName);
    }
    private static void readUsingCommonsIo(String fileName) throws IOException {
        File file = new File(fileName);
        System.out.println("使用Commons-io读取文件......");
        System.out.println(FileUtils.readFileToString(file, StandardCharsets.UTF_8));
    }
}
