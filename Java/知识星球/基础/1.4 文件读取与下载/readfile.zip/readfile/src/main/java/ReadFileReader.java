import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileReader {
    public static void main(String[] args) throws IOException {
        String fileName = "C:\\Users\\powerful\\Desktop\\test.txt";
        //使用FileReader读取，没有编码支持，效率不高
        readUsingFileReader(fileName);
    }
    private static void readUsingFileReader(String fileName) throws IOException {
        File file = new File(fileName);
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String line;
        System.out.println("使用FileReader读取文本文件......");
        while((line = br.readLine()) != null){
            //逐行读取
            System.out.println(line);
        }
        br.close();
        fr.close();
    }
}
