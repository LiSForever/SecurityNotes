import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * 编号7089
 */
public class ReadFiles {
    public static void main(String[] args) throws IOException {
        String fileName = "C:\\Users\\powerful\\Desktop\\test.txt";
        //使用Java 7中的Files类处理小文件，获取完整的文件数据
        readUsingFiles(fileName);
    }
    private static void readUsingFiles(String fileName) throws IOException {
        Path path = Paths.get(fileName);
        //将文件读取到字节数组
        byte[] bytes = Files.readAllBytes(path);
        System.out.println("使用File类读取文件.........");
        @SuppressWarnings("unused")
        List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        System.out.println(new String(bytes));
    }
}
