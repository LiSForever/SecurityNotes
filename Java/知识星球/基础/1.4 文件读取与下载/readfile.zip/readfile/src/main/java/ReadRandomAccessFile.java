import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * 编号7089
 */
public class ReadRandomAccessFile {
    public static void main(String[] args) throws IOException {
        String fileName = "C:\\Users\\powerful\\Desktop\\test.txt";
        //使用RandomAccessFile来实现断点续传读取/下载文件
        readUsingRandomAccessFile(fileName);
    }
    private static void readUsingRandomAccessFile(String fileName) throws IOException {
        RandomAccessFile file = new RandomAccessFile(fileName, "r");
        String str;
        while ((str = file.readLine()) != null) {
            System.out.println("使用RandomAccessFile来实现断点续传读取/下载文件......");
            System.out.println(str);
        }
        file.close();

    }
}
