package com.example.demo.codeexec;

import java.util.Arrays;
import java.util.List;

/**
 * 编号7089
 */
public class ProcessBuilderGetConstructor {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("java.lang.ProcessBuilder");
        Object object = clazz.getConstructor(List.class).newInstance(Arrays.asList("calc.exe"));
        clazz.getMethod("start").invoke(object,null);
    }
}
