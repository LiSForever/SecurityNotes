package com.example.demo.reflectdemo;

/**
 * 编号7089
 */
public class UserInfo {
    private String name;
    public int age;

    public UserInfo() { }

    private UserInfo(String name) {
        this.name = name;
    }

    public UserInfo(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    private String introduce() {
        return "我叫" + name + "，今年" + age + "岁了！";
    }

    public String sayHello() {
        return "Hello！我叫[" + name + "]";
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
