package com.example.demo.reflectdemo;
import java.lang.reflect.Constructor;
public class ConstructorDemo {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("com.example.demo.reflectdemo.UserInfo");

        // 获取一个声明为 public 构造函数实例
        Constructor<?> constructor1 = clazz.getConstructor(String.class,int.class);
        System.out.println("1-getConstructor运行结果：" + constructor1);
        // 根据构造函数创建一个实例
        Object c1 = constructor1.newInstance("power7089",18);
        System.out.println("2-newInstance运行结果： " + c1);

        // 获取所有声明为 public 构造函数实例
        Constructor<?>[] constructorArray1 = clazz.getConstructors();
        for (Constructor<?> constructor : constructorArray1) {
            System.out.println("3-getConstructors运行结果：" + constructor);
        }
        // 获取一个声明的构造函数实例
        Constructor<?> constructor2 = clazz.getDeclaredConstructor(String.class);
        System.out.println("4-getDeclaredConstructor运行结果：" + constructor2);
        // 将构造函数的可访问标志设为 true 后，可以通过私有构造函数创建实例
        constructor2.setAccessible(true);
        Object o2 = constructor2.newInstance("Power7089666");
        System.out.println("5-newInstance运行结果：" + o2);

        // 获取所有声明的构造函数实例
        Constructor<?>[] constructorArray2 = clazz.getDeclaredConstructors();
        for (Constructor<?> constructor : constructorArray2) {
            System.out.println("6-getDeclaredConstructors运行结果：" + constructor);
        }
    }
}
