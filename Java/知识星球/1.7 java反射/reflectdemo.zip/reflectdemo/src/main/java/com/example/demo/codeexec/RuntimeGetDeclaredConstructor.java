package com.example.demo.codeexec;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * 编号7089
 */
public class RuntimeGetDeclaredConstructor {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("java.lang.Runtime");
        Constructor m = clazz.getDeclaredConstructor();
        m.setAccessible(true);
        Method c1 = clazz.getMethod("exec", String.class);
        c1.invoke(m.newInstance(), "calc.exe");

    }
}
