package com.example.demo.entity;

/**
 * 编号7089
 */
public class User {
    public String name = "power7089";
    public String getName() {
        return name;
    }
    public void setName(String testStr) {
        this.name = name;
    }
}
