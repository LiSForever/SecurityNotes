package com.example.demo.reflectdemo;
import java.lang.reflect.Modifier;

/**
 * 编号7089
 */
public class ModifierDemo {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("com.example.demo.reflectdemo.UserInfo");

        // 获取类的修饰符值
        int modifiers1 = clazz.getModifiers();
        System.out.println("获取类的修饰符值getModifiers运行结果：" + modifiers1);

        // 获取属性的修饰符值
        int modifiers2 = clazz.getDeclaredField("name").getModifiers();
        System.out.println("获取属性的修饰符值getModifiers运行结果：" + modifiers2);

        // 获取方法的修饰符值
        int modifiers4 = clazz.getDeclaredMethod("setName", String.class).getModifiers();
        System.out.println("获取方法的修饰符值getModifiers运行结果：" + modifiers4);

        // 根据修饰符值，获取修饰符标志的字符串
        String modifier = Modifier.toString(modifiers1);
        System.out.println("获取类的修饰符值的字符串结果：" + modifier);
        System.out.println("获取属性的修饰符值字符串结果：" + Modifier.toString(modifiers2));
    }
}
