package com.example.demo.reflectdemo;
import java.lang.reflect.Modifier;

/**
 * 编号7089
 */
public class ClassDemo {

    public static void main(String[] args) throws ClassNotFoundException {
        Class clazz = Class.forName("com.example.demo.reflectdemo.UserInfo");
        // 获取该类所在包路径
        Package aPackage = clazz.getPackage();
        System.out.println("getPackage运行结果：" + aPackage);

        // 获取类上的修饰符
        int modifiers = clazz.getModifiers();
        String modifier = Modifier.toString(modifiers);
        System.out.println("getModifiers运行结果：" + modifier);

        // 获取类名称
        String name = clazz.getName();
        System.out.println("getName运行结果：" + name);

        // 获取简单类名
        String simpleName = clazz.getSimpleName();
        System.out.println("getSimpleName运行结果：" + simpleName);
        }
}

