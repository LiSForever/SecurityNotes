package com.example.demo.codeexec;
import java.lang.reflect.Method;

/**
 * 编号7089
 */
public class RuntimeGetMethod {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("java.lang.Runtime");
        Method execMethod = clazz.getMethod("exec", String.class);
        Method getRuntimeMethod = clazz.getMethod("getRuntime");
        Object runtime = getRuntimeMethod.invoke(clazz);
        execMethod.invoke(runtime, "calc.exe");
    }
}
