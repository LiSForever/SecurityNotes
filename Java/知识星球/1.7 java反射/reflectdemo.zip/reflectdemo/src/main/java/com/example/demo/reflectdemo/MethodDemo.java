package com.example.demo.reflectdemo;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class MethodDemo {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("com.example.demo.reflectdemo.UserInfo");
        // 获取一个该类及父类中声明为 public 的方法，需要指定方法的入参类型
        Method method = clazz.getMethod("setName", String.class);
        System.out.println("01-getMethod运行结果：" + method);
        // 获取所有入参
        Parameter[] parameters = method.getParameters();
        for (Parameter temp : parameters) {
            System.out.println("getParameters运行结果 " + temp);
        }

        // 获取该类及父类中所有声明为 public 的方法
        Method[] methods = clazz.getMethods();
        for (Method temp : methods) {
            System.out.println("02-getMethods运行结果：" + temp);
        }

        // 获取一个在该类中声明的方法
        Method declaredMethod = clazz.getDeclaredMethod("getName");
        System.out.println("03-getDeclaredMethod运行结果：" + declaredMethod);

        // 获取所有在该类中声明的方法
        Method[] declaredMethods = clazz.getDeclaredMethods();
        for (Method temp : declaredMethods) {
            System.out.println("04-getDeclaredMethods运行结果：" + temp);
        }
    }
}
