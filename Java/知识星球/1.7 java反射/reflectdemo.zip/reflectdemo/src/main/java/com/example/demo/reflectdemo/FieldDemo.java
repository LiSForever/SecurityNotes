package com.example.demo.reflectdemo;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
/**
 * 编号7089
 */
public class FieldDemo {
    public static void main(String[] args) throws Exception{
        Class<?> clazz = Class.forName("com.example.demo.reflectdemo.UserInfo");

        // 获取一个该类或父类中声明为 public 的属性
        Field field1 = clazz.getField("age");
        System.out.println("getField运行结果：" + field1);

        // 获取该类及父类中所有声明为 public 的属性
        Field[] fieldArray1 = clazz.getFields();
        for (Field field : fieldArray1) {
            System.out.println("getFields运行结果：" + field);
        }

        // 获取一个该类中声明的属性
        Field field2 = clazz.getDeclaredField("name");
        System.out.println("getDeclaredField运行结果：" + field2);

        // 获取某个属性的修饰符（该示例为获取上面name属性的修饰符）
        String modifier = Modifier.toString(field2.getModifiers());
        System.out.println("getModifiers运行结果： " + modifier);

        // 获取该类中所有声明的属性
        Field[] fieldArray2 = clazz.getDeclaredFields();
        for (Field field : fieldArray2) {
            System.out.println("getDeclaredFields运行结果：" + field);
        }
    }
}

