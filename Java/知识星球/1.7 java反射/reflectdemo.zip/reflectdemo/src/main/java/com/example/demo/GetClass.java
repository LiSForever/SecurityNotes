package com.example.demo;
import com.example.demo.entity.User;

/**
 * 编号7089
 */
public class GetClass {
    public static void main(String[] args) throws ClassNotFoundException {
        //1.通过类名.class
        Class c1 = User.class;

        //2.通过对象的getClass()方法
        User user = new User();
        Class c2 = user.getClass();

        //3.通过 Class.forName()获得Class对象;
        Class c3 = Class.forName("com.example.demo.entity.User");

        //4.通过类加载器获得class对象
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        Class c4 = classLoader.loadClass("com.example.demo.entity.User");

        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);
    }
}
